<?php
namespace backend\modules\ph\controllers;

use Yii;
use common\components\MainController;
use common\models\SystemEvents;
use backend\models\pricehunt\PricehuntObjects;
use common\models\Aggregator;
use common\models\mongo\MT_API;
use common\models\mongo\api\pricehuntAPI;
use backend\models\event\Event;


class DefaultController extends MainController
{

    public $apiSource = ['MT_flashboxAPI' => 490, 'MT_shakhtarAPI' => 998, 'MT_karabasAPI' => 491, 'MT_concertAPI' => 2953, 'MT_anshlagAPI' => 3174];


    public function actionIndex()
    {
        return false;
    }

    public function actionCreateSysEvent()
    {                                                                     
        $post     = Yii::$app->request->post();

        if(!isset($post['subtype'], $post['msg'], $post['data'], $post['type'], $post['eid'])) return false;

        $subtype = $post['subtype'];
        $msg     = $post['msg'];
        $data    = $post['data'];
        $type    = $post['type'];
        $eid     = $post['eid'];

        $eid     = PricehuntObjects::findOne(['phKey' => $eid]);
        $eid     = Event::findOne(['object_id' => $eid->object_id]);
        $eid     = $eid ? $eid : null;

        return  SystemEvents::createSystemEvent($subtype, $msg, null, $eid->id, null, $type, $data);
    }

    public function actionCollectDataEvent()
    {

     $query = 'SELECT col."event_api_key", api_acc."aggType", col."account_api_id"'.
         ' FROM pricehunt_eventmap event, pricehunt_api_collector col, api_accounts api_acc'.
         ' WHERE col."pricehunt_emid" = event."pricehunt_emid"'.
         ' AND api_acc."id" = col."account_api_id"'.
         ' AND event."date" >= now()';

     $query = Yii::$app->db->createCommand($query)->queryAll();

     foreach ($query as $event) {
         
        $aggData = new Aggregator();
        $classAgg = trim($event['aggType']);
        $aggData->aggType = $classAgg;
        $aggData->eventKey = $event['event_api_key'];
        $aggData->account_id = $event['account_api_id'];       

        include_once realpath(dirname(__FILE__).'/../../../../common/models/mongo/'.$classAgg.'.php');

        $aggRun = new $classAgg($aggData);
        $ticket_list = $aggRun->getTicketsList($event['event_api_key']);

        $aggRun->writeStatistic(str_replace('MT_', 'Stat_', $classAgg), $ticket_list, $event['event_api_key']);
     }

    }

    public function actionCollectEventsList()
    {
        
     $query = 'SELECT "id" as account_id, "aggType" FROM api_accounts ORDER BY id';

     $query = Yii::$app->db->createCommand($query)->queryAll();

     foreach ($query as $api_account) {
         
        $aggData = new Aggregator();         
        $classAgg = trim($api_account['aggType']);
        $aggData->aggType = $classAgg;
        $aggData->account_id = $api_account['account_id'];       
        
        include_once realpath(dirname(__FILE__).'/../../../../common/models/mongo/'.$classAgg.'.php');

        $aggRun = new $classAgg($aggData);
        $eventsList = $aggRun->getEventList($api_account['account_id']);

        $connection = new \MongoClient("mongodb://127.0.0.1:27017", ['username' => 'tickethuntMongo', 'password' => '####', 'db' => 'event_lists']);
        $collection = $classAgg;
        $mongo = $connection->selectDB('event_lists');
        if (isset($mongo->{$collection})) {
            $statCollection = $mongo->{$collection};
        } else {
            $statCollection = $mongo->selectCollection($collection);
        }

        $find_stat = $statCollection->findOne(['updateDate' => ['$gt' => strtotime(date("Y-m-d 00:00:00", time())), '$lt' => time()]]);null;

        if (!$find_stat['updateDate'])
        {
            $chunk = array_chunk((array)$eventsList, 50, TRUE);
            foreach ($chunk as $save_chunk)
            {
               $data = [
                  'updateDate' => time(),
                  'eventsList' => $save_chunk
               ];
                
               $statCollection->insert($data);        
            }
        }    
     }                
        $connection->close();
    }        

    public function actionSendDataEvent($eid)
    {
    
    }    

    public function actionSendEventLists()
    {
        $connection = new \MongoClient("mongodb://127.0.0.1:27017", ['username' => 'tickethuntMongo', 'password' => '#####', 'db' => 'event_lists']);
        $phapi = new pricehuntAPI();
        $mongo = $connection->selectDB('event_lists');
        $collections = $mongo->listCollections();       
        foreach ($collections as $collection) 
        {
             $find_items = $collection->find();            
             if($find_items->count() > 0)
             {
                 $data['sid'] = $this->apiSource[$collection->getName()];                                
                 foreach ($find_items as $find_item)
                 {                           
                     $data['data'] = json_encode((array)$find_item['eventsList']);                     
                     $resp = json_decode($phapi->setSendEventLists($data), true);
                     echo json_encode($resp);
                     if (isset($resp['status']) && $resp['status'] == 0)
                     {                      
                         $collection->remove(['_id' => $find_item['_id']]);
                     }    
                 }    
             }
        }
    }    
    
    public function actionGetApiData() // сбор апи
    {
        return '45';
    }


}
