<?php
namespace backend\modules\ph;

use Yii;

class Module extends \yii\base\Module implements \yii\base\BootstrapInterface
{
    public $controllerNamespace = 'backend\modules\ph\controllers';
    public $allowedIPs = ['*'];

    protected function checkAccess()
    {
        $ip = Yii::$app->getRequest()->getUserIP();
        foreach ($this->allowedIPs as $filter)
        {
            if ($filter === '*' || $filter === $ip || (($pos = strpos($filter, '*')) !== false && !strncmp($ip, $filter, $pos)))
            {
                return true;
            }
        }        
        return false;
    }
    
    public function beforeAction($action)
    {
        if (!parent::beforeAction($action))
        {
            return false;
        }
        if (Yii::$app instanceof \yii\web\Application && !$this->checkAccess())
        {
            return false;
        }       
        return true;
    }

    
    public function bootstrap($app)    
    {
        parent::bootstrap();
    }
}

?>
