local server = require "resty.websocket.server"
local pgmoon = require "pgmoon"
local json = require "cjson"

local pg = pgmoon.new({host ="127.0.0.1", port ="5432", user = "postgres", password ="AB6kocc9pm", database = "testtickethunt" })           

pg:connect()

    local wb, err = server:new{
        -- timeout = 5000,  -- in milliseconds -- не надо нам таймаут
        max_payload_len = 65535,
    }

    if not wb then
        ngx.log(ngx.ERR, "failed to new websocket: ", err)
        return ngx.exit(444)
    end

    while true do
        local data, typ, err = wb:recv_frame()

        if wb.fatal then return
        elseif not data then
            ngx.log(ngx.DEBUG, "Sending Websocket ping")
            wb:send_ping()
        elseif typ == "close" then
            -- send a close frame back:
            local bytes, err = wb:send_close(1000, "enough, enough!")
            if not bytes then
                ngx.log(ngx.ERR, "failed to send the close frame: ", err)
                return
            end
            local code = err
            ngx.log(ngx.INFO, "closing with status code ", code, " and message ", data)
            break;
        elseif typ == "ping" then
            -- send a pong frame back:

            local bytes, err = wb:send_pong(data)
            if not bytes then
                ngx.log(ngx.ERR, "failed to send frame: ", err)
                return
            end
        elseif typ == "pong" then
            -- just discard the incoming pong frame

        elseif data then

            if wb == nil then
                ngx.log(ngx.ERR, "WebSocket instaince is NIL");
                return ngx.exit(444)
            end

        wb:send_text(data)

            -- общее колличество записей    
        local kol_rec = pg:query([[SELECT COUNT(*) as kol_rec FROM view_refresh_api_list]])

        for key, val in pairs(kol_rec) do
            count_rec = val["kol_rec"]            
        end    
            wb:send_text("Общее колличество записей: " .. count_rec)
        
        local cikls = math.floor(count_rec/10)
            wb:send_text("Колличество циклов: " .. cikls)
            
            -- выбираем и отправляем по 10 запросов в одном реквесте
		local limitUpdate = 4	
        for off_set = 0, cikls*limitUpdate, 10 do

           local batchs = pg:query('SELECT id AS operation_id FROM view_refresh_api_list LIMIT '..limitUpdate..' OFFSET '..off_set)
           local kol_rec = #batchs
         
           wb:send_text("Колличество записей в цикле: " .. kol_rec)
        

		   local reqs = {}

           -- создаем таблицу запросов
		   for key, val in pairs(batchs) do
				table.insert(reqs, { "/luaapi/default/process-api-data", {args = "id="..val["operation_id"]}})
		   end    
        
			co = coroutine.create(function (reqs)
				wb:send_text('Поток создан')
				coroutine.yield()
				local resps = { ngx.location.capture_multi(reqs) }			
				for i, resp in ipairs(resps) do
					wb:send_text(resp.body)
				end
				wb:send_text('Поток отбработан')
			end)
		end
		coroutine.resume(co)
		
        else
            ngx.log(ngx.INFO, "received a frame of type ", typ, " and payload ", data)
        end
    end
