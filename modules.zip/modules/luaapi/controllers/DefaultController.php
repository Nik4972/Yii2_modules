<?php
namespace backend\modules\luaapi\controllers;

use Yii;
use common\components\MainController;
use common\models\SystemEvents;
use common\models\ApiLog;
use common\models\Aggregator;
use common\models\Event;

class DefaultController extends MainController
{        
        
    public function actionIndex() 
    {
                    $get = Yii::$app->request->get();                              
                    if(empty($get['id']))
                    {
                        return 'Id is empty!';
                        
                    } else {   
                        
                        $end = null;
                        $aggData = Aggregator::findOne(['id' => $get['id']]);
                        $attempt = $aggData->number_update_attempts;                       
                        try
                        {
                            $start = microtime(true); 
                            $event = Event::findOne(['aggregator_id' => $get['id']]);
                            $classAgg = trim($aggData->aggType);
                            include_once realpath(dirname(__FILE__).'/../../../../common/models/mongo/'.$classAgg.'.php');
                            $aggData = (object)$aggData;
                            $aggData->event_id = $event->id;                    
                            $aggRun = new $classAgg($aggData);                        
                          //  $aggRun->setTickets(0, false); 
                          
                            sleep(rand(1, 10));
                            $end = microtime(true) - $start;
                            ApiLog::writeLog($classAgg, 'event api update', $end, 'Событие '.$event->name.' обновленно за '.$end, $aggData->eventKey, null, null);
                            if($end > 120) 
                            {
                                $attempt ++;    
                                SystemEvents::createSystemEvent('api update attempt', 'Ошибка обновления события из АПИ. Событие - <a target="blank" href="https://tickethunt.net/ru/event/'.$event->object_id.'/a">'.$event->name.'</a> обновлялось '.$end.' секунд. Приоритет изменен.', null, $event->id, null, SystemEvents::SYS_EVENT_INFO, json_encode($aggData, JSON_UNESCAPED_UNICODE));
                            }
                        } 
                        catch (\Exception $e)
                        {
                            $attempt ++;
                            SystemEvents::createSystemEvent('error api update', 'Ошибка обновления события из АПИ. Событие - <a target="blank" href="https://tickethunt.net/ru/event/'.$event->object_id.'/a">'.$event->name.'</a>', null, $event->id, null, SystemEvents::SYS_EVENT_CRITICAL, json_encode(['error' => $e->getFile().':'.$e->getLine().' '.$e->getMessage(), 'debug' => $aggData], JSON_UNESCAPED_UNICODE));
                        }
                        finally
                        {
                            $aggData->last_refresh = date('Y-m-d H:i:s', time());
                            $aggData->last_refresh_time = $end;
                            $aggData->number_update_attempts = $attempt;
                         //   $aggData->save();    
                            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON; 
                            Yii::$app->response->data  =  ['eventName' => $event->name,  'eventObjectid' => $event->object_id, 'timeRefresh' => $aggData->last_refresh_time,  'apiClass' =>  $classAgg];
                            Yii::$app->response->send();                         
                    }

    }

    }
    
}
?>

